package p;

class C {
	public void k()
	{
		B b = new B();
		b.n = 7;
		b.g();
	}
}
