package p;

class E extends B {
	void f()
	{
		n = 3;
		g();
	}
}
