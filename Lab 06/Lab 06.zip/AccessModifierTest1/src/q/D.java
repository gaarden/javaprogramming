package q;

import p.B;

class D extends B {
	void f()
	{
		n = 3;
		g();
	}
}
